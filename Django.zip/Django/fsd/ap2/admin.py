from django.contrib import admin

from ap2.models import Admin, User



# Register your models here.
admin.site.register(Admin)
admin.site.register(User)